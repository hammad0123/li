package com.lti.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.model.Employee;

@Service
public class EmployeeServices {
	
	List<Employee> employeeList=Arrays.asList(
			new Employee("100","Roy",1000),
			new Employee("101","joy",2000),
			new Employee("102","Noy",3000)
			);
	
	public List<Employee> getAllEmployees(){
		
		return employeeList;
	}
	
	
	public void addEmployee(Employee employee) {
		
		
		employeeList.add(employee);
	}


	public void deleteEmployees(String id) {

		
		employeeList.removeIf(t -> t.getId().equals(id));
	}
	
	

}
