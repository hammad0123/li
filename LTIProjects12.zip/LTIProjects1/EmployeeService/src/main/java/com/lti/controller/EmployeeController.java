package com.lti.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Employee;
import com.lti.services.EmployeeServices;
import com.sun.tools.javac.util.List;

@RestController
public class EmployeeController {
	
	
	@Autowired
	private EmployeeServices employeeService;

	
	@RequestMapping("/Employees")
	public java.util.List<Employee> fetchEmployees()
	{
		return  employeeService.getAllEmployees();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/Employees")
	public void addEmployee(@RequestBody Employee employee) {
		
		employeeService.addEmployee(employee);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/Employees/{id}")
	public void deleteEmployees(@PathVariable String id)
	{
		employeeService.deleteEmployees(id);
	}

}