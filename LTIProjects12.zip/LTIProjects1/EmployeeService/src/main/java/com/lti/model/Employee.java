package com.lti.model;

public class Employee {
	
	private String id;
	private String employeeName;
	private int salary;
	
	public Employee(String id, String employeeName, int salary) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.salary = salary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getSalary() {
		return salary;
	}
	public void setsalary(int salary) {
		this.salary = salary;
	}

}
